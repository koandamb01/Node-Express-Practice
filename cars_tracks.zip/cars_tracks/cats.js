module.exports = [
    {
        name: "Tela",
        food: ['rice', 'spaghetti', 'cheese'],
        age: 4,
        sleeping_spots: ['couch', 'salon', 'door step']
    },
    {
        name: "Moula",
        food: ['rice', 'Foofoo'],
        age: 2,
        sleeping_spots: ['couch', 'door step']
    },
    {
        name: "Dorine",
        food: ['rice', 'spaghetti', 'meat'],
        age: 1,
        sleeping_spots: ['couch', 'salon', 'bed']
    }
]